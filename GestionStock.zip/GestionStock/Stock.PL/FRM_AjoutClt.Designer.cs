﻿namespace GestionStock.Stock.PL
{
    partial class FRM_AjoutClt
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel2 = new System.Windows.Forms.Panel();
            this.btnQuit = new System.Windows.Forms.Button();
            this.btnValidClt = new System.Windows.Forms.Button();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblFicheClt = new System.Windows.Forms.Label();
            this.textTel = new System.Windows.Forms.TextBox();
            this.textMail = new System.Windows.Forms.TextBox();
            this.textPays = new System.Windows.Forms.TextBox();
            this.textVille = new System.Windows.Forms.TextBox();
            this.textAdresse = new System.Windows.Forms.TextBox();
            this.textPrenom = new System.Windows.Forms.TextBox();
            this.textNom = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.btnAnnuler = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel2.Location = new System.Drawing.Point(111, 451);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(778, 10);
            this.panel2.TabIndex = 48;
            // 
            // btnQuit
            // 
            this.btnQuit.BackColor = System.Drawing.Color.AntiqueWhite;
            this.btnQuit.FlatAppearance.BorderSize = 0;
            this.btnQuit.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnQuit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnQuit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnQuit.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnQuit.ForeColor = System.Drawing.Color.Firebrick;
            this.btnQuit.Location = new System.Drawing.Point(633, 490);
            this.btnQuit.Name = "btnQuit";
            this.btnQuit.Size = new System.Drawing.Size(122, 43);
            this.btnQuit.TabIndex = 47;
            this.btnQuit.Text = "Quitter";
            this.btnQuit.UseVisualStyleBackColor = false;
            this.btnQuit.Click += new System.EventHandler(this.btnQuit_Click);
            // 
            // btnValidClt
            // 
            this.btnValidClt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
            this.btnValidClt.FlatAppearance.BorderColor = System.Drawing.Color.Firebrick;
            this.btnValidClt.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnValidClt.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnValidClt.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnValidClt.Font = new System.Drawing.Font("Candara", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnValidClt.ForeColor = System.Drawing.Color.Firebrick;
            this.btnValidClt.Location = new System.Drawing.Point(227, 491);
            this.btnValidClt.Name = "btnValidClt";
            this.btnValidClt.Size = new System.Drawing.Size(122, 43);
            this.btnValidClt.TabIndex = 46;
            this.btnValidClt.Text = "Valider";
            this.btnValidClt.UseVisualStyleBackColor = false;
            this.btnValidClt.Click += new System.EventHandler(this.btnValidClt_Click);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.panel1.Controls.Add(this.lblFicheClt);
            this.panel1.Location = new System.Drawing.Point(111, 86);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(778, 66);
            this.panel1.TabIndex = 45;
            // 
            // lblFicheClt
            // 
            this.lblFicheClt.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.lblFicheClt.AutoSize = true;
            this.lblFicheClt.Font = new System.Drawing.Font("Candara", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFicheClt.ForeColor = System.Drawing.Color.AntiqueWhite;
            this.lblFicheClt.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblFicheClt.Location = new System.Drawing.Point(321, 17);
            this.lblFicheClt.Name = "lblFicheClt";
            this.lblFicheClt.Size = new System.Drawing.Size(127, 28);
            this.lblFicheClt.TabIndex = 0;
            this.lblFicheClt.Text = "Fiche Client";
            // 
            // textTel
            // 
            this.textTel.Font = new System.Drawing.Font("Candara", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textTel.ForeColor = System.Drawing.Color.Silver;
            this.textTel.Location = new System.Drawing.Point(607, 345);
            this.textTel.Name = "textTel";
            this.textTel.Size = new System.Drawing.Size(225, 28);
            this.textTel.TabIndex = 42;
            this.textTel.Text = "Téléphone";
            this.textTel.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textTel_KeyPress);
            // 
            // textMail
            // 
            this.textMail.Font = new System.Drawing.Font("Candara", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textMail.ForeColor = System.Drawing.Color.Silver;
            this.textMail.Location = new System.Drawing.Point(227, 342);
            this.textMail.Name = "textMail";
            this.textMail.Size = new System.Drawing.Size(225, 28);
            this.textMail.TabIndex = 41;
            this.textMail.Text = "Mail";
            // 
            // textPays
            // 
            this.textPays.Font = new System.Drawing.Font("Candara", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textPays.ForeColor = System.Drawing.Color.Silver;
            this.textPays.Location = new System.Drawing.Point(666, 283);
            this.textPays.Name = "textPays";
            this.textPays.Size = new System.Drawing.Size(166, 28);
            this.textPays.TabIndex = 40;
            this.textPays.Text = "Pays";
            // 
            // textVille
            // 
            this.textVille.Font = new System.Drawing.Font("Candara", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textVille.ForeColor = System.Drawing.Color.Silver;
            this.textVille.Location = new System.Drawing.Point(392, 279);
            this.textVille.Name = "textVille";
            this.textVille.Size = new System.Drawing.Size(197, 28);
            this.textVille.TabIndex = 39;
            this.textVille.Text = "Ville";
            // 
            // textAdresse
            // 
            this.textAdresse.Font = new System.Drawing.Font("Candara", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textAdresse.ForeColor = System.Drawing.Color.Silver;
            this.textAdresse.Location = new System.Drawing.Point(227, 226);
            this.textAdresse.Name = "textAdresse";
            this.textAdresse.Size = new System.Drawing.Size(605, 28);
            this.textAdresse.TabIndex = 37;
            this.textAdresse.Text = "Adresse client";
            // 
            // textPrenom
            // 
            this.textPrenom.Font = new System.Drawing.Font("Candara", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textPrenom.ForeColor = System.Drawing.Color.Silver;
            this.textPrenom.Location = new System.Drawing.Point(607, 178);
            this.textPrenom.Name = "textPrenom";
            this.textPrenom.Size = new System.Drawing.Size(225, 28);
            this.textPrenom.TabIndex = 36;
            this.textPrenom.Text = "Prénom client";
            // 
            // textNom
            // 
            this.textNom.Font = new System.Drawing.Font("Candara", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textNom.ForeColor = System.Drawing.Color.Silver;
            this.textNom.Location = new System.Drawing.Point(227, 178);
            this.textNom.Name = "textNom";
            this.textNom.Size = new System.Drawing.Size(225, 28);
            this.textNom.TabIndex = 35;
            this.textNom.Text = "Nom de client";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Candara", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.Firebrick;
            this.label8.Location = new System.Drawing.Point(509, 345);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(86, 21);
            this.label8.TabIndex = 32;
            this.label8.Text = "Téléphone";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Candara", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Firebrick;
            this.label7.Location = new System.Drawing.Point(156, 345);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(58, 21);
            this.label7.TabIndex = 31;
            this.label7.Text = "Email*";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Candara", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.Firebrick;
            this.label6.Location = new System.Drawing.Point(603, 286);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(51, 21);
            this.label6.TabIndex = 30;
            this.label6.Text = "Pays*";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Candara", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Firebrick;
            this.label5.Location = new System.Drawing.Point(326, 281);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 21);
            this.label5.TabIndex = 29;
            this.label5.Text = "Ville*";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Candara", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.Firebrick;
            this.label3.Location = new System.Drawing.Point(156, 228);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(67, 21);
            this.label3.TabIndex = 27;
            this.label3.Text = "Adresse";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Candara", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Firebrick;
            this.label2.Location = new System.Drawing.Point(509, 178);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 21);
            this.label2.TabIndex = 26;
            this.label2.Text = "Prénom*";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Candara", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Firebrick;
            this.label1.Location = new System.Drawing.Point(157, 181);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(54, 21);
            this.label1.TabIndex = 25;
            this.label1.Text = "Nom*";
            // 
            // btnAnnuler
            // 
            this.btnAnnuler.BackColor = System.Drawing.Color.AntiqueWhite;
            this.btnAnnuler.FlatAppearance.BorderSize = 0;
            this.btnAnnuler.FlatAppearance.MouseDownBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btnAnnuler.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btnAnnuler.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAnnuler.Font = new System.Drawing.Font("Candara", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAnnuler.ForeColor = System.Drawing.Color.Firebrick;
            this.btnAnnuler.Location = new System.Drawing.Point(437, 490);
            this.btnAnnuler.Name = "btnAnnuler";
            this.btnAnnuler.Size = new System.Drawing.Size(122, 43);
            this.btnAnnuler.TabIndex = 49;
            this.btnAnnuler.Text = "Annuler";
            this.btnAnnuler.UseVisualStyleBackColor = false;
            this.btnAnnuler.Click += new System.EventHandler(this.btnAnnuler_Click);
            // 
            // FRM_AjoutClt
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 22F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 619);
            this.Controls.Add(this.btnAnnuler);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.btnQuit);
            this.Controls.Add(this.btnValidClt);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.textTel);
            this.Controls.Add(this.textMail);
            this.Controls.Add(this.textPays);
            this.Controls.Add(this.textVille);
            this.Controls.Add(this.textAdresse);
            this.Controls.Add(this.textPrenom);
            this.Controls.Add(this.textNom);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Candara", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "FRM_AjoutClt";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "FRM_AjoutClt";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        public System.Windows.Forms.Label lblFicheClt;
        public System.Windows.Forms.Button btnQuit;
        public System.Windows.Forms.Button btnValidClt;
        public System.Windows.Forms.TextBox textTel;
        public System.Windows.Forms.TextBox textMail;
        public System.Windows.Forms.TextBox textPays;
        public System.Windows.Forms.TextBox textVille;
        public System.Windows.Forms.TextBox textAdresse;
        public System.Windows.Forms.TextBox textPrenom;
        public System.Windows.Forms.TextBox textNom;
        public System.Windows.Forms.Button btnAnnuler;
    }
}